Lab scheduler example. No remote repository.
